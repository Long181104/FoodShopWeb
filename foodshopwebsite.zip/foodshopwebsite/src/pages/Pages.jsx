import React, { useState } from "react";
import { Alert, Button } from "react-bootstrap";

const Pages = () => {
  

  return (
        <div>
            
        </div>
  );
};

export default Pages;

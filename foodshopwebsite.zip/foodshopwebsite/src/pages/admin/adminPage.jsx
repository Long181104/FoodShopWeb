import React from 'react';

const adminPage = () => {
    return (
        <div>
            
        </div>
    );
};

export default adminPage;